<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD Application in PHP using AJAX - Coding Birds Online</title>
    <link rel="shortcut icon"
        href="https://demo.codingbirdsonline.com/website/img/coding-birds-online/coding-birds-online-favicon.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="custom.css">
</head>

<body>

    <div class="container">
        <a href="javaScript:void(0);" data-toggle="modal" data-target="#myModal"
            class="btn btn-primary pull-right bottom-gap">Add New <i class="fa fa-plus" aria-hidden="true"></i></a>
        <table class="table table-bordered">
            <thead id="thead" style="background-color:#135361">
                <tr>
                    <th>Sr.No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>DOB</th>
                    <th>Contact</th>
                    <th>Gender</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>Courses</th>
                    <th>Hobby</th>
                    <th>Image</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody id="crudData"></tbody>
        </table>
    </div>
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">CRUD Application Form</h4>
                </div>
                <div class="modal-body">
                    <form id="crudAppForm" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">Name <span class="field-required">*</span></label>
                                    <input type="text" name="name" id="name" placeholder="Name" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">Email <span class="field-required">*</span></label>
                                    <input type="text" name="email" id="email" placeholder="Email" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="password">Password <span class="field-required">*</span></label>
                                    <input type="password" name="password" id="password" placeholder="password"
                                        class="form-control">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="dob">DOB<span class="field-required">*</span></label>
                                    <input type="date" name="dob" id="dob" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="contact">Contact <span class="field-required">*</span></label>
                                    <input type="text" name="contact" id="contact" placeholder="Contact"
                                        class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="gender">Gender <span class="field-required">*</span></label><br>
                                    <input type="radio" name="gender" id="gender" value="Male">Male
                                    <input type="radio" name="gender" id="gender" value="Female">Female
                                    <input type="radio" name="gender" id="gender" value="Other">Other
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="city">City<span class="field-required">*</span></label>
                                    <br>
                                    <select class="form-control" name="city" id="city">
                                        <option value="">select...</option>
                                        <option value="Mumbai">Mumbai</option>
                                        <option value="Delhi">Delhi</option>
                                        <option value="Ahmedabad">Ahmedabad</option>
                                        <option value="Banglore">Banglore</option>
                                        <option value="Hyderabad">Hyderabad</option>
                                        <option value="Kolkata">Kolkata</option>
                                    </select>
                                </div>
                            </div>
<!--                            <div class="col-md-6">-->
<!--                                <div class="form-group">-->
<!--                                    <label for="courses">Courses<span class="field-required">*</span></label>-->
<!--                                    <select class="form-control" name="courses[]" id="courses" multiple>-->
<!--                                        <option value="">select...</option>-->
<!--                                        <option value="Computer Science">Computer Science</option>-->
<!--                                        <option value="Software engineering">Software engineering</option>-->
<!--                                        <option value="BCA">BCA</option>-->
<!--                                        <option value="Graphic design">Graphic design</option>-->
<!--                                        <option value="Web design">Web design</option>-->
<!--                                        <option value="Data science">Data science</option>-->
<!--                                    </select>-->
<!--                                </div>-->
<!--                            </div>-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="hobby">Hobby <span class="field-required">*</span></label>
                                    <br>
                                    Drawing<input type="checkbox" name="hobby[]" value="Drawing" id="hobby" />
                                    Singing<input type="checkbox" name="hobby[]" value="Singing" id="hobby" />
                                    Dancing<input type="checkbox" name="hobby[]" value="Dancing" id="hobby" />
                                    Sketching<input type="checkbox" name="hobby[]" value="Sketching" id="hobby" />
                                    Other<input type="checkbox" name="hobby[]" value="Other" id="hobby">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="address">Address <span class="field-required">*</span></label>
                                    <textarea name="address" id="address" placeholder="address"
                                              class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="courses">Courses<span class="field-required">*</span></label>
                                    <select class="form-control" name="courses[]" id="courses" multiple>
                                        <option value="">select...</option>
                                        <option value="Computer Science">Computer Science</option>
                                        <option value="Software engineering">Software engineering</option>
                                        <option value="BCA">BCA</option>
                                        <option value="Graphic design">Graphic design</option>
                                        <option value="Web design">Web design</option>
                                        <option value="Data science">Data science</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="image">Image<span class="field-required">*</span></label>
                                    <input type="file" name="image" id="image" class="form-control" >
                                </div>
                            </div>
                        </div>


                </div>
                <!-- <div id="preview">
                    <h3>Image Preview</h3>
                    <div class="imagePreview"></div>
                </div> -->
                <div class="modal-footer">
                    <input type="hidden" name="editId" id="editId" value="" />
                    <button type="submit" name="submitBtn" id="submitBtn" class="btn btn-primary"><i
                                class="fa fa-spinner fa-spin" id="spinnerLoader"></i> <span
                                id="buttonLabel">Save</span>
                    </button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="crud-app.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <script>
        $(document).ready(function () {
            $('#crudAppForm').submit(function (e) {
                e.preventDefault();
                // Validate required fields
                var requiredFields = ['name', 'email', 'password', 'dob', 'contact', 'gender', 'address', 'city', 'courses[]', 'hobby[]'];
                var isValid = true;

                requiredFields.forEach(function (field) {
                    if (!$('[name="' + field + '"]').val()) {
                        isValid = false;
                        return false; // exit loop early if any field is empty
                    }
                });

                if (!isValid) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Validation Error',
                        text: 'Please fill in all required fields.',
                    });
                    return;
                }
                // Disable the submit button to prevent multiple submissions
                $('#submitBtn').prop('disabled', true);

                // Show loading spinner
                $('#spinnerLoader').show();
                $('#buttonLabel').text('Saving...');

                // Serialize form data
                var formData = new FormData($(this)[0]);

                $.ajax({
                    type: 'POST',
                    url: 'save_data.php',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function (response) {
                        var result = JSON.parse(response);

                        if (result.status === 'success') {
                            // Handle success with SweetAlert
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: result.message,
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    location.reload(); // Reload the page
                                }
                            });
                        } else {
                            // Handle error with SweetAlert
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: result.message,
                            });
                        }

                        // Enable the submit button and hide the loading spinner
                        $('#submitBtn').prop('disabled', false);
                        $('#spinnerLoader').hide();
                        $('#buttonLabel').text('Save');
                    },
                    error: function () {
                        // Handle AJAX error
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Error occurred during AJAX request',
                        });


                        // Enable the submit button and hide the loading spinner
                        $('#submitBtn').prop('disabled', false);
                        $('#spinnerLoader').hide();
                        $('#buttonLabel').text('Save');
                    }
                });
            });
        });
    </script>

<!--     <script>-->
<!--        $(document).ready(function(){-->
<!--            $('#crudAppForm').on("submit",function(e){-->
<!--                e.preventDefault();-->
<!--                var formData = new FormData(this);-->
<!--                $.ajax({-->
<!--                    url: "upload.php",-->
<!--                    method:"POST",-->
<!--                    contentType : false,-->
<!--                    processData : false,-->
<!--                    data : formData,-->
<!--                    success: function(data) {-->
<!--                        $("#preview").show();-->
<!--                        $("#imagePreview").html(data);-->
<!--                        $('#image').val('');-->
<!--                    }-->
<!--                });-->
<!--            });-->
<!--            //Delete image -->
<!--            $('#delete_btn').click(function() {-->
<!--                if (confirm("Are you sure to Delete this image?")) {-->
<!--                    var imgName = $(this).attr('id');-->
<!--                    var path = $("#delete_btn").data("path");-->
<!--                    $.ajax({-->
<!--                        url: 'delete.php',-->
<!--                        type: 'post',-->
<!--                        data:{path:path},-->
<!--                        success: function(response) {-->
<!--                            if(data != ""){-->
<!--                                $("#preview").hide();-->
<!--                                $("#imagePreview").html('');-->
<!--                            }-->
<!--                        }-->
<!--                    });-->
<!--                }-->
<!--            });-->
<!--        });-->
<!--    </script>-->
</body>

</html>